import csv
import matplotlib.pyplot as plt    

with open ('athlete_events.csv','r') as csv_file:
  arq=csv.reader(csv_file)

  next(arq)
  
  pais=input('Defina o país de pesquisa:')
  ano_olimp_=int(input('A partir de que ano você quer os dados ?:'))
  ano_olimp = 2016 - ano_olimp_
  tipo_olimp=input('Olimpiada de verão (Summer) ou inverno (Winter) ?:')

  medalhasM=dict()
  qtd_medalhasM=list()
  medalhasM['Ouro']=0
  medalhasM['Prata']=0
  medalhasM['Bronze']=0

##MASCULINO

  for linha in arq:
    if str(linha[2]) == 'M' and str(linha[6]) == pais and int(linha[9]) >= ano_olimp and str(linha[10]) == tipo_olimp and str(linha[14]) != 'NA':
    
      if str(linha[14]) == 'Gold':
        medalhasM['Ouro']=medalhasM['Ouro']+1
      elif str(linha[14]) == 'Silver':
        medalhasM['Prata']=medalhasM['Prata']+1
      elif str(linha[14]) == 'Bronze':
        medalhasM['Bronze']=medalhasM['Bronze']+1

#QUANTIDADE DE MEDALHAS, EM SEQUENCIA (OURO, PRATA E BRONZE)

  for medalha in medalhasM.values():
    qtd_medalhasM.append(medalha)
  print(qtd_medalhasM)